<?php


?>






<!DOCTYPE html>
<html lang="en">
<head>
    <title>Name of the website</title>
</head>

<body>
<!--Sidenav-->
<div class="list-group bg-info" style="height: 90vh">
    <a href="index.php" class="list-group-item list-group-item-action bg-info text-center">Dashboard</a>
    <a href="profile.php" class="list-group-item list-group-item-action bg-info text-center">Profile</a>
    <a href="admin.php" class="list-group-item list-group-item-action bg-info text-center">Administrators</a>
    <a href="doctor.php" class="list-group-item list-group-item-action bg-info text-center">Doctors
    <br>
    (temp)</a>
    <a href="patient.php" class="list-group-item list-group-item-action bg-info text-center">Patients</a>
</div>
<!--END Sidenav-->
</body>

</html>
