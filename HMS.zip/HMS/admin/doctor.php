<?php
session_start();
include("../include/connection.php");

if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}

?>

<!DOCTYPE html>
<html>

<head>
    <title>Total Doctors</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
<?php
include("../include/header.php");
?>

<div class="container-fluid">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-2" style="margin-left: -30px">
                <?php include("sidenav.php"); ?>
            </div>
            <div class="col-md-10" style="margin-top: 50px">
                <h5 class="text-center">Total Doctors</h5>
                <?php
                // Query to fetch doctors with 'Approved' status
                $query = "SELECT * FROM doctors WHERE status='Approved' ORDER BY data_reg ASC";
                $res = mysqli_query($connect, $query);

                if (!$res) {
                    die("Query failed: " . mysqli_error($connect));
                }

                $output = "<table class='table table-bordered'>
                            <tr>
                                <th>ID</th>
                                <th>Firstname</th>
                                <th>Surname</th>
                                <th>Username</th>
                                <th>Gender</th>
                                <th>Phone</th>
                                <th>Country</th>
                                <th>Salary</th>
                                <th>Date Registered</th>
                                <th>Action</th>
                            </tr>";

                if (mysqli_num_rows($res) < 1) {
                    $output .= "<tr>
                                    <td colspan='10' class='text-center'>No doctors found</td>
                                </tr>";
                } else {
                    while ($row = mysqli_fetch_array($res)) {
                        $output .= "<tr>
                                        <td>{$row['id']}</td>
                                        <td>{$row['firstname']}</td>
                                        <td>{$row['surname']}</td>
                                        <td>{$row['username']}</td>
                                        <td>{$row['gender']}</td>
                                        <td>{$row['phone']}</td>
                                        <td>{$row['country']}</td>
                                        <td>{$row['salary']}</td>
                                        <td>{$row['data_reg']}</td>
                                        <td>
                                            <a href='edit.php?id={$row['id']}'>
                                                <button class='btn btn-info'>Edit</button>
                                            </a>
                                        </td>
                                    </tr>";
                    }
                }

                $output .= "</table>";

                echo $output;
                ?>
            </div>
        </div>
    </div>
</div>
</body>
</html>
