<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Check Now Page</title>
    <!-- Add Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include("../include/header.php"); // Include header ?>

    <div class="container my-5">
        <h1>DR.GIRIDHARAN(Multi Specialist)</h1>
        <p>Welcome to special time booking!!!. You can book appointment with our Senior specalist!!!.</p>
        
        <!-- Example link to an external resource -->
        <a href="https://calendly.com/221801504-rajalakshmi/30min" class="btn btn-primary" target="_blank">BOOK NOW!!</a>

        <!-- Example internal link -->
        <a href="index.php" class="btn btn-secondary">Back</a>
    </div>

    <div class="container my-5">
        <h1>DR.MADHUVANTHIY(Cardiologist)</h1>
        <p>Welcome to special time booking!!!. You can book appointment with our Top doctor specalist in CARDIOLOGY!!!</p>
        
        <!-- Example link to an external resource -->
        <a href="https://calendly.com/221801504-rajalakshmi/30min" class="btn btn-primary" target="_blank">BOOK NOW!!</a>

        <!-- Example internal link -->
        <a href="index.php" class="btn btn-secondary">Back</a>
    </div>


    <div class="container my-5">
        <h1>DR.BALAMBIGAI(Neurologist)</h1>
        <p>Welcome to special time booking!!!. You can book appointment with our Top doctor specalist in NEUROLOGY!!!</p>
        
        <!-- Example link to an external resource -->
        <a href="https://calendly.com/221801504-rajalakshmi/30min" class="btn btn-primary" target="_blank">BOOK NOW!!</a>

        <!-- Example internal link -->
        <a href="index.php" class="btn btn-secondary">Back</a>
    </div>
          

    <!-- Add Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
