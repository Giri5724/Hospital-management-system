<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Patient Dashboard</title>
    <!-- Add Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Add Font Awesome CSS for icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        .dashboard-option {
            height: 150px;
        }
    </style>
</head>
<body>
<?php
include ("../include/header.php");
include ("../include/connection.php");
?>

<div class="container-fluid">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-2" style="margin-left: -30px">
                <?php include ("sidenav.php"); ?>
            </div>
            <div class="col-md-10">
                <h5>Patient Dashboard</h5>

                <div class="col-md-12">
                    <div class="row">
                        <!-- Existing Options -->
                        <div class="col-md-3 bg-info mx-2 dashboard-option">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-8">
                                        <h5 class="text-white my-4">My Profile</h5>
                                    </div>
                                    <div class="col-md-4">
                                        <a href="profile.php">
                                            <i class="fa fa-user-circle fa-3x my-4" style="color: white"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 bg-warning mx-2 dashboard-option">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-8">
                                        <h5 class="text-white my-4">Book Appointment</h5>
                                    </div>
                                    <div class="col-md-4">
                                        <a href="appointment.php">
                                            <i class="fa fa-calendar fa-3x my-4" style="color: white"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3 bg-success mx-2 dashboard-option">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-8">
                                        <h5 class="text-white my-4">My Invoice</h5>
                                    </div>
                                    <div class="col-md-4">
                                        <a href="invoice.php">
                                            <i class="fa fa-file-invoice-dollar fa-3x my-4" style="color: white"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- New VIP BOOKING Option -->
                        <div class="col-md-3 bg-primary mx-2 dashboard-option">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-8">
                                        <h5 class="text-white my-4">VIP BOOKING</h5>
                                    </div>
                                    <div class="col-md-4">
                                        <a href="vipbooking.php">
                                            <i class="fa fa-check-circle fa-3x my-4" style="color: white"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php
                if (isset($_POST['send'])) {
                    $title = $_POST['title'];
                    $message = $_POST['message'];

                    if (empty($title) || empty($message)) {
                        // Handle empty input cases
                        echo "<script>alert('Title and Message are required.')</script>";
                    } else {
                        $user = $_SESSION['patient'];
                        // Use prepared statements to prevent SQL injection
                        $stmt = $con->prepare("INSERT INTO report (title, message, username, date_send) VALUES (?, ?, ?, NOW())");
                        $stmt->bind_param('sss', $title, $message, $user);
                        $res = $stmt->execute();

                        if ($res) {
                            echo "<script>alert('You have sent Your Report')</script>";
                        } else {
                            echo "<script>alert('Failed to send report.')</script>";
                        }
                        $stmt->close();
                    }
                }
                ?>

                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-3"></div>
                        <div class="col-md-6 jumbotron bg-info my-5">
                            <h5 class="text-center">Send A Request</h5>
                            <form action="" method="post">
                                <label for="title">Title</label>
                                <input type="text" name="title" autocomplete="off" class="form-control" placeholder="Enter Title of the report">

                                <label for="message">Message</label>
                                <input type="text" name="message" autocomplete="off" class="form-control" placeholder="Enter Message">

                                <input type="submit" name="send" value="Send Report" class="btn btn-success my-2">
                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- Add Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
