<!DOCTYPE html>
<html>
<head>
    <title>View Invoice</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://pay.google.com/gp/p/js/pay.js"></script>
</head>

<body>
<?php include("../include/header.php"); ?>

<div class="container-fluid">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-2" style="margin-left: -30px">
                <?php include("sidenav.php"); ?>
            </div>
            <div class="col-md-10">
                <h5 class="text-center my-2">View Invoice</h5>

                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-3"></div>
                        <div class="col-md-6">
                            <table class="table table-bordered">
                                <tr>
                                    <th colspan="2" class="text-center">Invoice Details</th>
                                </tr>
                                <tr>
                                    <td>Doctor</td>
                                    <td>Dr. Smith</td>
                                </tr>
                                <tr>
                                    <td>Patient</td>
                                    <td>John Doe</td>
                                </tr>
                                <tr>
                                    <td>Date Discharge</td>
                                    <td>2024-08-12</td>
                                </tr>
                                <tr>
                                    <td>Amount Paid</td>
                                    <td>$200</td>
                                </tr>
                                <tr>
                                    <td>Description</td>
                                    <td>Consultation and treatment</td>
                                </tr>
                            </table>

                            <div class="text-center my-5">
                                <button id="google-pay-button" class="btn btn-primary">
                                    <img src="https://img.icons8.com/?size=100&id=w0MU3YDSYG7T&format=png&color=000000" alt="Google Pay" style="height: 24px;">
                                    Pay with Google Pay
                                </button>
                            </div>

                            <script>
                                const button = document.getElementById('google-pay-button');
                                button.addEventListener('click', () => {
                                    // Simulate payment by redirecting to a simulated payment page
                                    window.location.href = 'simulate_payment.php';
                                });
                            </script>
                        </div>
                        <div class="col-md-3"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
