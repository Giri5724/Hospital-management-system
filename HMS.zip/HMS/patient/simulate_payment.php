<!DOCTYPE html>
<html>
<head>
    <title>Simulate Payment</title>
    <meta http-equiv="refresh" content="2;url=profile.php?status=paid">
</head>
<body>
    <p>Processing payment...<br>
        paying...<br>
    payment sucess!!</p>
    <!-- Simulate a delay before redirecting -->
    <script>
        setTimeout(() => {
            window.location.href = 'profile.php?status=paid';
        }, 5000); // 2 seconds delay
    </script>
</body>
</html>
