<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Name of the website</title>
</head>

<body>
<!--Sidenav-->
<div class="list-group bg-info" style="height: 90vh">
    <a href="index.php" class="list-group-item list-group-item-action bg-info text-center">Dashboard</a>
    <a href="profile.php" class="list-group-item list-group-item-action bg-info text-center">Profile</a>
    <a href="patient.php" class="list-group-item list-group-item-action bg-info text-center">Patients</a>
    <a href="appointment.php" class="list-group-item list-group-item-action bg-info text-center">Appointments</a>
    <a href="report.php" class="list-group-item list-group-item-action bg-info text-center">Reports</a>
</div>
<!--END Sidenav-->
</body>

</html>

