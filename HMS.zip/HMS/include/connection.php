connection

<?php
$servername = "localhost"; // or your database server address
$username = "root";        // your database username (could be 'pma' if not using root)
$password = "";            // your database password (for root user, this is usually empty)
$database = "newhms";   // your database name

// Create connection
$connect = new mysqli($servername, $username, $password, $database);

// Check connection
if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
}
?>
